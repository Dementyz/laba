﻿USE DB_Books

SELECT SUM(Purchases.Стоимость)
FROM Purchases, Deliveries
WHERE Purchases.Код_поставщика = Deliveries.Код_поставщика
  AND Deliveries.Название_компании = 'ЗАО Оптторг'
