﻿USE DB_Books

SELECT ФИО_автора FROM Authors
WHERE NOT EXISTS (SELECT * FROM Books WHERE Books.Код_автора = Authors.Код_автора)
