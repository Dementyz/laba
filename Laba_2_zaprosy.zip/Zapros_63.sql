﻿USE DB_Books

DELETE FROM Purchases
WHERE Количество = 0
