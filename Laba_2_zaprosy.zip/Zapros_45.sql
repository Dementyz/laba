﻿USE DB_Books

SELECT Deliveries.Название_компании, Books.Название_книги
FROM Deliveries, Books, Purchases
WHERE Purchases.Код_поставщика = Deliveries.Код_поставщика
  AND Purchases.Код_книги = Books.Код_книги
