﻿USE DB_Books

SELECT ФИО_ответственного, Телефон, ИНН FROM Deliveries
ORDER BY ИНН DESC
