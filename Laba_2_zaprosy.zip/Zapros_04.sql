﻿USE DB_Books

SELECT ФИО_ответственного, ИНН, Телефон, Юридический_адрес, Код_поставщика FROM Deliveries
