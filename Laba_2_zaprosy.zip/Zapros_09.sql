﻿USE DB_Books

SELECT Название_компании, Телефон, ИНН FROM Deliveries
WHERE Название_компании LIKE 'ОАО%'
