﻿USE DB_Books

UPDATE Books SET Количество_страниц = 300
WHERE Код_автора = 56 AND Название_книги = 'Мемуары'
