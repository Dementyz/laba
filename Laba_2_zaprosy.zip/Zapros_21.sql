﻿USE DB_Books

SELECT ФИО_автора FROM Authors
WHERE ФИО_автора LIKE 'К%'
