﻿USE DB_Books

SELECT Authors.Код_автора, Authors.ФИО_автора, Books.Название_книги
FROM Authors, Books
WHERE Authors.Код_автора = Books.Код_автора
  AND Books.Код_издательства BETWEEN 10 AND 25 AND Books.Количество_страниц > 120
