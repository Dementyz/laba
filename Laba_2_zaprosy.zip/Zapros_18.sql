﻿USE DB_Books

SELECT Books.Название_книги, Purchases.Количество
FROM Books, Purchases
WHERE Books.Код_книги = Purchases.Код_книги AND Purchases.Код_поставщика IN (3, 7, 9, 11)
