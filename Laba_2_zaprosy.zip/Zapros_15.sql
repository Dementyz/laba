﻿USE DB_Books

SELECT Books.Название_книги, Purchases.Количество
FROM Books, Purchases
WHERE Books.Код_книги = Purchases.Код_книги
  AND Purchases.Дата_заказа BETWEEN '20030312' AND '20030615'
