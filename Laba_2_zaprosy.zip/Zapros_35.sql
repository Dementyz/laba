﻿USE DB_Books

SELECT COUNT(Код_покупки) FROM Purchases
WHERE Дата_заказа BETWEEN '20030101' AND '20030201'
