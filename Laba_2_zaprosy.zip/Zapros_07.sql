﻿USE DB_Books

SELECT Books.Название_книги, Books.Количество_страниц, Deliveries.ФИО_ответственного
FROM Books, Purchases, Deliveries
WHERE Books.Код_книги = Purchases.Код_книги AND Purchases.Код_поставщика = Deliveries.Код_поставщика
