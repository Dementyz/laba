﻿USE DB_Books

SELECT DISTINCT Authors.ФИО_автора
FROM Authors, Books, Publishing_house
WHERE Authors.Код_автора = Books.Код_автора
  AND Books.Код_издательства = Publishing_house.Код_издательства
  AND Publishing_house.Издательство IN ('Мир', 'Питер Софт', 'Наука')
