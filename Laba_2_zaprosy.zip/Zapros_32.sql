﻿USE DB_Books

SELECT Books.Название_книги, Purchases.Стоимость / Books.Количество_страниц
FROM Purchases, Books
WHERE Purchases.Код_книги = Books.Код_книги
