﻿USE DB_Books

SELECT Издательство FROM Publishing_house
WHERE Город <> 'Москва'
