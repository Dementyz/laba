﻿USE DB_Books

SELECT Purchases.*, Books.Название_книги
FROM Purchases, Books
WHERE Purchases.Код_книги = Books.Код_книги
  AND Purchases.Стоимость * Purchases.Количество =
      (SELECT MIN(Стоимость * Количество) FROM Purchases)
