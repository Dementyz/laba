﻿USE DB_Books

SELECT Название_книги FROM Books
WHERE EXISTS (SELECT * FROM Purchases, Deliveries
              WHERE Purchases.Код_книги = Books.Код_книги
                AND Purchases.Код_поставщика = Deliveries.Код_поставщика
                AND Deliveries.Название_компании = 'ЗАО Квантор')
