﻿USE DB_Books

UPDATE Deliveries SET Юридический_адрес = 'нет сведений'
WHERE Юридический_адрес IS NULL OR Юридический_адрес = ''
