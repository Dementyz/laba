﻿USE DB_Books

SELECT Books.Название_книги, Books.Количество_страниц, Authors.ФИО_автора
FROM Books, Authors
WHERE Books.Код_автора = Authors.Код_автора AND Books.Название_книги LIKE 'Мемуары%'
