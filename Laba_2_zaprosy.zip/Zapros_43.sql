﻿USE DB_Books

SELECT ФИО_автора FROM Authors
WHERE DATEDIFF(year, Дата_рождения, GETDATE()) < 170
