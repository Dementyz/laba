﻿USE DB_Books

SELECT Название_книги FROM Books
WHERE Количество_страниц > (SELECT AVG(Количество_страниц) FROM Books)
