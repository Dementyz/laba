﻿USE DB_Books

SELECT Purchases.Код_поставщика, Purchases.Дата_заказа, Books.Название_книги
FROM Purchases, Books
WHERE Purchases.Код_книги = Books.Код_книги
  AND (Purchases.Количество > 100 OR Purchases.Стоимость BETWEEN 200 AND 500)
