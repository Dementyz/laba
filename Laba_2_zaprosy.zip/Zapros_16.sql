﻿USE DB_Books

SELECT Название_книги, Количество_страниц FROM Books
WHERE Количество_страниц BETWEEN 200 AND 300
