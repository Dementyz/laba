﻿USE DB_Books

SELECT Издательство, Город, Код_издательства FROM Publishing_house
