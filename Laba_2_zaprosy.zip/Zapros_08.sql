﻿USE DB_Books

SELECT Books.Название_книги, Books.Количество_страниц, Publishing_house.Издательство, Publishing_house.Город
FROM Books, Publishing_house
WHERE Books.Код_издательства = Publishing_house.Код_издательства
