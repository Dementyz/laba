﻿USE DB_Books

SELECT ФИО_автора, DATEDIFF(year, Дата_рождения, GETDATE())
FROM Authors
