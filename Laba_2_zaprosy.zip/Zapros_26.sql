﻿USE DB_Books

SELECT DISTINCT Publishing_house.Издательство
FROM Publishing_house, Books
WHERE Publishing_house.Код_издательства = Books.Код_издательства
  AND Books.Название_книги LIKE 'Труды%' AND Publishing_house.Город = 'Новосибирск'
