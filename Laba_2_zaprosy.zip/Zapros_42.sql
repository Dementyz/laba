﻿USE DB_Books

SELECT * FROM Purchases
WHERE Дата_заказа >= DATEADD(month, -1, GETDATE())
