﻿USE DB_Books

SELECT Издательство FROM Publishing_house
WHERE Издательство LIKE '%софт%'
