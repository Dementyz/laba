﻿USE DB_Books

CREATE TABLE Authors(Код_автора INT PRIMARY KEY, ФИО_автора CHAR(30), Дата_рождения DATETIME)

CREATE TABLE Publishing_house(Код_издательства INT PRIMARY KEY, Издательство CHAR(30), Город CHAR(20))

CREATE TABLE Books(Код_книги INT PRIMARY KEY, Название_книги CHAR(40),
  Код_автора INT FOREIGN KEY REFERENCES Authors(Код_автора), Количество_страниц INT,
  Код_издательства INT FOREIGN KEY REFERENCES Publishing_house(Код_издательства))

CREATE TABLE Deliveries(Код_поставщика INT PRIMARY KEY, ФИО_ответственного CHAR(30),
  Название_компании CHAR(20), Юридический_адрес VARCHAR(100), Телефон BIGINT, ИНН CHAR(13))

CREATE TABLE Purchases(Код_покупки INT PRIMARY KEY, Код_книги INT FOREIGN KEY REFERENCES Books(Код_книги),
  Дата_заказа SMALLDATETIME, Код_поставщика INT FOREIGN KEY REFERENCES Deliveries(Код_поставщика),
  Тип_закупки BIT, Стоимость FLOAT, Количество INT)
