﻿USE DB_Books

SELECT Books.Название_книги, Purchases.Количество * Purchases.Стоимость AS Itogo
FROM Purchases, Books
WHERE Purchases.Код_книги = Books.Код_книги
  AND Purchases.Дата_заказа BETWEEN '20020101' AND '20020601'
