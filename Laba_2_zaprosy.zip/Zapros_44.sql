﻿USE DB_Books

SELECT Books.Название_книги
FROM Books, Purchases
WHERE Books.Код_книги = Purchases.Код_книги AND Purchases.Количество < 60
