﻿USE DB_Books

SELECT Books.Название_книги
FROM Books, Publishing_house
WHERE Books.Код_издательства = Publishing_house.Код_издательства
  AND Publishing_house.Издательство IN ('Питер-Софт', 'Альфа', 'Наука')
