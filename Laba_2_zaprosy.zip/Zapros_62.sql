﻿USE DB_Books

INSERT INTO Publishing_house (Код_издательства, Издательство, Город)
SELECT ISNULL(MAX(Код_издательства), 0) + 1, 'Наука', 'Москва' FROM Publishing_house
