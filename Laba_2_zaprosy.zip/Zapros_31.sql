﻿USE DB_Books

SELECT Books.Название_книги, Purchases.Количество * Purchases.Стоимость
FROM Purchases, Books
WHERE Purchases.Код_книги = Books.Код_книги
