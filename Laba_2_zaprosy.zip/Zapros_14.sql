﻿USE DB_Books

SELECT ФИО_автора FROM Authors
WHERE Дата_рождения BETWEEN '18400101' AND '18600601'
