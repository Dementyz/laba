﻿USE DB_Books

UPDATE Purchases SET Стоимость = Стоимость * 1.2
WHERE Дата_заказа >= DATEADD(month, -1, GETDATE())
