﻿USE DB_Books

SELECT DISTINCT Deliveries.Название_компании
FROM Deliveries, Purchases
WHERE Deliveries.Код_поставщика = Purchases.Код_поставщика
  AND Purchases.Стоимость = 150
