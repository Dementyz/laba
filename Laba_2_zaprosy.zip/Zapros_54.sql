﻿USE DB_Books

SELECT Издательство FROM Publishing_house
WHERE EXISTS (SELECT * FROM Books, Purchases
              WHERE Books.Код_издательства = Publishing_house.Код_издательства
                AND Purchases.Код_книги = Books.Код_книги AND Purchases.Тип_закупки = 1)
