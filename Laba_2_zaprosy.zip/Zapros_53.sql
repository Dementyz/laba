﻿USE DB_Books

SELECT Название_книги FROM Books
WHERE Количество_страниц = (SELECT MIN(Количество_страниц) FROM Books)
