﻿USE DB_Books

SELECT ФИО_автора FROM Authors
WHERE LEFT(ФИО_автора, 1) BETWEEN 'В' AND 'Г'
