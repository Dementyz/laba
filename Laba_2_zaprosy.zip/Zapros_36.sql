﻿USE DB_Books

SELECT AVG(Purchases.Стоимость), AVG(Purchases.Количество)
FROM Purchases, Books, Authors
WHERE Purchases.Код_книги = Books.Код_книги AND Books.Код_автора = Authors.Код_автора
  AND Authors.ФИО_автора LIKE 'Акунин%'
