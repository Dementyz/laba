﻿USE DB_Books

DELETE FROM Deliveries
WHERE ИНН IS NULL OR ИНН = ''
