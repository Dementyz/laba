﻿USE DB_Books

SELECT Название_компании FROM Deliveries
WHERE RTRIM(Название_компании) LIKE '%ский'
