﻿USE DB_Books

SELECT SUM(Purchases.Стоимость) AS Sum_cost
FROM Purchases, Deliveries
WHERE Purchases.Код_поставщика = Deliveries.Код_поставщика
  AND Deliveries.Название_компании = 'ОАО Луч'
