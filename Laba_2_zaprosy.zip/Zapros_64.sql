﻿USE DB_Books

DELETE FROM Authors
WHERE ФИО_автора IS NULL OR ФИО_автора = ''
