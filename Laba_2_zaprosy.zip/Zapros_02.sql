﻿USE DB_Books

SELECT Код_книги, Название_книги, Количество_страниц FROM Books
ORDER BY Название_книги ASC, Количество_страниц DESC
