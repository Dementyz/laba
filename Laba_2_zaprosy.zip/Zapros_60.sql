﻿USE DB_Books

INSERT INTO Purchases (Код_покупки, Код_книги, Дата_заказа, Код_поставщика, Тип_закупки, Стоимость, Количество)
SELECT ISNULL(MAX(Код_покупки), 0) + 1, 1, GETDATE(), 1, 1, 300, 10 FROM Purchases
