﻿USE DB_Books

SELECT Purchases.Стоимость / Books.Количество_страниц AS One_page, Books.Название_книги
FROM Purchases, Books
WHERE Purchases.Код_книги = Books.Код_книги
