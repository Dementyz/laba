﻿USE DB_Books

SELECT Books.Название_книги
FROM Books, Authors
WHERE Books.Код_автора = Authors.Код_автора
  AND Authors.ФИО_автора IN ('Толстой Л.Н.', 'Достоевский Ф.М.', 'Пушкин А.С.')
