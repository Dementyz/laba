﻿USE DB_Books

INSERT INTO Authors VALUES (1, 'Иванов Иван Иванович', '19550310')
INSERT INTO Authors VALUES (2, 'Толстой Л.Н.', '18280909')
INSERT INTO Authors VALUES (3, 'Пушкин А.С.', '17990606')
INSERT INTO Authors VALUES (4, 'Акунин Борис', '19560520')
INSERT INTO Authors VALUES (5, 'Чехов А.П.', '18600129')

INSERT INTO Publishing_house VALUES (1, 'Питер-Софт', 'Санкт-Петербург')
INSERT INTO Publishing_house VALUES (2, 'Мир', 'Москва')
INSERT INTO Publishing_house VALUES (3, 'Наука', 'Новосибирск')
INSERT INTO Publishing_house VALUES (4, 'Альфа', 'Екатеринбург')
INSERT INTO Publishing_house VALUES (5, 'Питер', 'Санкт-Петербург')

INSERT INTO Books VALUES (1, 'Война и мир', 2, 1300, 2)
INSERT INTO Books VALUES (2, 'Евгений Онегин', 3, 250, 1)
INSERT INTO Books VALUES (3, 'Мемуары', 4, 280, 4)
INSERT INTO Books VALUES (4, 'Труды по литературе', 5, 120, 3)
INSERT INTO Books VALUES (5, 'Вишневый сад', 5, 120, 5)

INSERT INTO Deliveries VALUES (1, 'Орлов В.И.', 'ОАО Книготорг', 'г. Москва, ул. Тверская, 5', 84952202020, '7701987654')
INSERT INTO Deliveries VALUES (2, 'Зайцева М.О.', 'ЗАО Оптторг', 'г. Екатеринбург, ул. Ленина, 10', 83432101010, '6670123456')
INSERT INTO Deliveries VALUES (3, 'Сергеев П.Ю.', 'ОАО Луч', 'г. Челябинск, пр. Победы, 21', 83512303030, '7451112233')
INSERT INTO Deliveries VALUES (4, 'Белов А.С.', 'ЗАО Квантор', 'г. Пермь, ул. Мира, 45', 83422334455, '5902445566')
INSERT INTO Deliveries VALUES (5, 'Козлова И.П.', 'ООО Уральский', '', 83432555111, '')

INSERT INTO Purchases VALUES (1, 1, '20020315', 1, 1, 450, 120)
INSERT INTO Purchases VALUES (2, 2, '20030312', 2, 0, 150, 50)
INSERT INTO Purchases VALUES (3, 3, '20030120', 3, 1, 300, 80)
INSERT INTO Purchases VALUES (4, 4, '20030601', 4, 1, 200, 0)
INSERT INTO Purchases VALUES (5, 5, '20251001', 4, 0, 150, 30)
