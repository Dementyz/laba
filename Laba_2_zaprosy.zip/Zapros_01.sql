﻿USE DB_Books

SELECT * FROM Books
ORDER BY Код_книги
